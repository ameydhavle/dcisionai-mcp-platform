
import json
import logging
from mcp_server import manufacturing_health_check, manufacturing_optimize

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    """Lambda handler for MCP server."""
    try:
        # Handle health check
        if event.get('httpMethod') == 'GET' and event.get('path') == '/health':
            result = manufacturing_health_check()
            return {
                'statusCode': 200,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps(result)
            }
        
        # Handle MCP requests
        if event.get('httpMethod') == 'POST' and event.get('path') == '/mcp':
            body = json.loads(event.get('body', '{}'))
            
            if body.get('method') == 'tools/call':
                tool_name = body.get('params', {}).get('name')
                arguments = body.get('params', {}).get('arguments', {})
                
                if tool_name == 'manufacturing_health_check':
                    result = manufacturing_health_check()
                elif tool_name == 'manufacturing_optimize':
                    problem_description = arguments.get('problem_description', '')
                    result = manufacturing_optimize(problem_description)
                else:
                    return {
                        'statusCode': 400,
                        'body': json.dumps({'error': 'Unknown tool'})
                    }
                
                return {
                    'statusCode': 200,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': '*'
                    },
                    'body': json.dumps({
                        'jsonrpc': '2.0',
                        'id': body.get('id'),
                        'result': result
                    })
                }
        
        return {
            'statusCode': 404,
            'body': json.dumps({'error': 'Not found'})
        }
        
    except Exception as e:
        logger.error(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
