#!/usr/bin/env python3
"""
Real Workflow Templates for DcisionAI Platform
==============================================

Predefined workflows that use the actual optimization engine with real data.
No mock responses - everything uses the genuine 4-step optimization pipeline.
"""

from typing import Dict, Any, List
import json

# Real workflow templates that use actual optimization
WORKFLOW_TEMPLATES = {
    "manufacturing": {
        "production_planning": {
            "id": "production_planning",
            "title": "Advanced Production Planning",
            "description": "Optimize multi-product production with capacity, labor, and material constraints",
            "problem_description": "Optimize production for 5 products across 3 production lines: Product A (demand: 1,200 units, profit: $25/unit, labor: 2.5 hrs/unit, material: $8/unit), Product B (demand: 800 units, profit: $18/unit, labor: 1.8 hrs/unit, material: $6/unit), Product C (demand: 600 units, profit: $32/unit, labor: 3.2 hrs/unit, material: $12/unit), Product D (demand: 400 units, profit: $28/unit, labor: 2.8 hrs/unit, material: $10/unit), Product E (demand: 300 units, profit: $35/unit, labor: 4.0 hrs/unit, material: $15/unit). Production line capacities: Line 1 (1,500 units/month, 3,000 labor hours), Line 2 (1,200 units/month, 2,400 labor hours), Line 3 (800 units/month, 1,600 labor hours). Material inventory: $50,000 available. Setup costs: $500 per product per line. Maximize total profit while meeting demand, capacity, labor, and material constraints.",
            "expected_intent": "production_optimization",
            "expected_entities": ["products", "production_lines", "capacity", "labor", "materials", "demand", "profit"],
            "industry": "manufacturing",
            "category": "production_planning",
            "difficulty": "advanced",
            "estimated_time": "4-5 minutes"
        },
        "supply_chain": {
            "id": "supply_chain",
            "title": "Global Supply Chain Optimization", 
            "description": "Optimize multi-tier supply chain with transportation and inventory costs",
            "problem_description": "Optimize global supply chain for 4 products across 5 suppliers and 6 distribution centers. Suppliers: Supplier A (China, capacity: 2,000 units, cost: $12/unit, lead time: 45 days), Supplier B (Mexico, capacity: 1,500 units, cost: $15/unit, lead time: 15 days), Supplier C (India, capacity: 1,800 units, cost: $10/unit, lead time: 60 days), Supplier D (USA, capacity: 1,200 units, cost: $18/unit, lead time: 7 days), Supplier E (Germany, capacity: 1,000 units, cost: $20/unit, lead time: 10 days). Distribution centers: DC1 (demand: 800 units, holding cost: $2/unit/month), DC2 (demand: 600 units, holding cost: $2.5/unit/month), DC3 (demand: 700 units, holding cost: $1.8/unit/month), DC4 (demand: 500 units, holding cost: $3/unit/month), DC5 (demand: 400 units, holding cost: $2.2/unit/month), DC6 (demand: 300 units, holding cost: $2.8/unit/month). Transportation costs vary by supplier-DC pair ($0.5-$3.0/unit). Minimize total cost including procurement, transportation, and inventory holding costs while meeting demand and capacity constraints.",
            "expected_intent": "supply_chain_optimization",
            "expected_entities": ["suppliers", "distribution_centers", "transportation", "inventory", "lead_times", "costs"],
            "industry": "manufacturing",
            "category": "supply_chain",
            "difficulty": "advanced",
            "estimated_time": "5-6 minutes"
        },
        "quality_control": {
            "id": "quality_control",
            "title": "Quality Control & Process Optimization",
            "description": "Optimize quality control processes with cost-benefit analysis",
            "problem_description": "Optimize quality control system for 3 production processes with different quality levels and costs. Process A (current: 95% yield, 100 units/hour, $3/unit cost, inspection cost: $0.50/unit), Process B (current: 92% yield, 120 units/hour, $2.80/unit cost, inspection cost: $0.40/unit), Process C (current: 98% yield, 80 units/hour, $3.50/unit cost, inspection cost: $0.60/unit). Quality improvement options: Enhanced inspection (+2% yield, +$0.20/unit cost), Process upgrade (+3% yield, +$0.30/unit cost), Advanced testing (+1% yield, +$0.15/unit cost). Defective units: Rework cost $15/unit, Scrap value $2/unit. Customer quality requirements: minimum 96% yield. Maximize profit while meeting quality standards and production targets of 1,000 units/day.",
            "expected_intent": "quality_optimization",
            "expected_entities": ["processes", "yield_rates", "inspection", "quality_improvements", "costs", "rework"],
            "industry": "manufacturing",
            "category": "quality_control",
            "difficulty": "advanced",
            "estimated_time": "4-5 minutes"
        }
    },
    
    "healthcare": {
        "staff_scheduling": {
            "id": "staff_scheduling",
            "title": "Comprehensive Healthcare Staff Scheduling",
            "description": "Optimize multi-skill healthcare staff scheduling with patient acuity and cost constraints",
            "problem_description": "Optimize healthcare staff scheduling for 7-day period across 3 shifts (Day: 6AM-2PM, Evening: 2PM-10PM, Night: 10PM-6AM). Staff: 15 RNs (cost: $45/hr, skills: general care), 8 LPNs (cost: $32/hr, skills: basic care), 5 CNAs (cost: $18/hr, skills: assistance), 3 Charge Nurses (cost: $55/hr, skills: supervision). Patient acuity levels: Level 1 (1:1 ratio, 20 patients), Level 2 (1:2 ratio, 35 patients), Level 3 (1:4 ratio, 60 patients), Level 4 (1:6 ratio, 40 patients). Staff preferences and availability vary by day. Overtime costs: 1.5x regular rate. Minimum staffing: 2 Charge Nurses per shift, 1 RN per 4 patients, 1 LPN per 6 patients. Maximize patient care quality while minimizing total labor costs and respecting staff preferences.",
            "expected_intent": "staff_optimization",
            "expected_entities": ["staff_types", "shifts", "patient_acuity", "ratios", "costs", "preferences"],
            "industry": "healthcare",
            "category": "staff_scheduling",
            "difficulty": "advanced",
            "estimated_time": "5-6 minutes"
        },
        "equipment_utilization": {
            "id": "equipment_utilization",
            "title": "Medical Equipment & Resource Optimization",
            "description": "Optimize medical equipment scheduling and resource allocation",
            "problem_description": "Optimize medical equipment scheduling for 5-day period: 2 MRI machines (capacity: 8 procedures/day each, maintenance: 2 hours daily), 3 CT scanners (capacity: 12 procedures/day each, maintenance: 1.5 hours daily), 2 Ultrasound units (capacity: 15 procedures/day each), 1 PET scanner (capacity: 6 procedures/day, maintenance: 3 hours daily). Procedure types: MRI (routine: 45 min, $800; contrast: 60 min, $1,200; emergency: 30 min, $1,500), CT (routine: 20 min, $400; contrast: 35 min, $600; emergency: 15 min, $800), Ultrasound (routine: 30 min, $200; specialized: 45 min, $350), PET (routine: 90 min, $2,500). Patient demand: 45 MRI, 60 CT, 80 Ultrasound, 12 PET procedures. Staff availability: 3 MRI techs, 4 CT techs, 2 Ultrasound techs, 1 PET tech. Maximize revenue while minimizing patient wait times and equipment downtime.",
            "expected_intent": "equipment_optimization",
            "expected_entities": ["equipment", "procedures", "staff", "maintenance", "revenue", "capacity"],
            "industry": "healthcare",
            "category": "equipment_utilization",
            "difficulty": "advanced",
            "estimated_time": "5-6 minutes"
        },
        "patient_flow": {
            "id": "patient_flow",
            "title": "Hospital Patient Flow & Capacity Optimization",
            "description": "Optimize patient flow through hospital departments with capacity constraints",
            "problem_description": "Optimize patient flow through hospital system: Emergency Department (arrival rate: 4.2 patients/hour, processing time: 45-180 minutes), Operating Rooms (4 ORs, procedure times: 60-300 minutes, setup: 30 minutes), ICU (12 beds, average stay: 3.2 days, occupancy: 85%), General Ward (45 beds, average stay: 4.5 days, occupancy: 78%), Discharge (processing time: 30-90 minutes). Patient categories: Emergency (priority 1, 25% of arrivals), Scheduled Surgery (priority 2, 35% of arrivals), Observation (priority 3, 40% of arrivals). Staff constraints: 6 ED doctors, 8 surgeons, 12 ICU nurses, 25 ward nurses. Bed capacity limits and transfer protocols. Minimize total patient wait time while maximizing throughput and maintaining quality of care standards.",
            "expected_intent": "patient_flow_optimization",
            "expected_entities": ["departments", "patient_categories", "beds", "staff", "wait_times", "capacity"],
            "industry": "healthcare",
            "category": "patient_flow",
            "difficulty": "advanced",
            "estimated_time": "5-6 minutes"
        }
    },
    
    "retail": {
        "inventory_optimization": {
            "id": "inventory_optimization",
            "title": "Multi-Location Inventory",
            "description": "Optimize stock levels across multiple store locations",
            "problem_description": "Optimize inventory across 3 store locations: Store 1 (capacity: 150 units), Store 2 (capacity: 100 units), Store 3 (capacity: 90 units). Product demands: Product A (100 units total), Product B (80 units total), Product C (60 units total). Holding costs: $2/unit/month. Stockout costs: $10/unit. Minimize total inventory costs while maximizing demand fulfillment.",
            "expected_intent": "inventory_optimization",
            "expected_entities": ["stores", "inventory", "demand", "costs"],
            "industry": "retail",
            "category": "inventory_management",
            "difficulty": "intermediate",
            "estimated_time": "3-4 minutes"
        },
        "dynamic_pricing": {
            "id": "dynamic_pricing",
            "title": "Dynamic Pricing Strategy",
            "description": "Optimize pricing for multiple products to maximize revenue",
            "problem_description": "Optimize pricing for 5 products: Product A (current: $10, elasticity: -1.2), Product B (current: $15, elasticity: -0.8), Product C (current: $20, elasticity: -1.5), Product D (current: $25, elasticity: -1.0), Product E (current: $30, elasticity: -0.9). Current total revenue: $15,000/month. Maximize revenue while maintaining competitive positioning.",
            "expected_intent": "pricing_optimization",
            "expected_entities": ["products", "pricing", "elasticity", "revenue"],
            "industry": "retail",
            "category": "pricing_strategy",
            "difficulty": "advanced",
            "estimated_time": "4-5 minutes"
        },
        "marketing_mix": {
            "id": "marketing_mix",
            "title": "Marketing Budget Allocation",
            "description": "Optimize marketing spend across multiple channels",
            "problem_description": "Optimize $10,000 monthly marketing budget across 4 channels: Social Media (current: $2,000, ROI: 3.2x), Email Marketing (current: $3,000, ROI: 4.1x), Search Ads (current: $3,000, ROI: 2.8x), Display Ads (current: $2,000, ROI: 2.1x). Each channel has minimum spend requirements: $500, $1,000, $1,500, $500 respectively. Maximize total ROI.",
            "expected_intent": "marketing_optimization",
            "expected_entities": ["channels", "budget", "roi", "allocation"],
            "industry": "retail",
            "category": "marketing",
            "difficulty": "intermediate",
            "estimated_time": "3-4 minutes"
        }
    },
    
    "marketing": {
        "comprehensive_marketing_optimization": {
            "id": "comprehensive_marketing_optimization",
            "title": "Comprehensive Marketing Spend Optimization",
            "description": "Optimize marketing budget allocation across channels, campaigns, and customer segments",
            "problem_description": "Optimize $50,000 monthly marketing budget across 6 channels and 3 customer segments. Channels: Google Ads (ROI: 4.2x, cost per click: $2.50), Facebook Ads (ROI: 3.8x, cost per click: $1.80), LinkedIn Ads (ROI: 5.1x, cost per click: $4.20), Email Marketing (ROI: 6.5x, cost per email: $0.15), Content Marketing (ROI: 2.8x, cost per article: $500), Influencer Marketing (ROI: 3.5x, cost per post: $2,000). Customer segments: Enterprise (LTV: $5,000, conversion: 8%), SMB (LTV: $1,200, conversion: 12%), Consumer (LTV: $300, conversion: 15%). Channel capacity limits: Google Ads max $15,000, Facebook max $12,000, LinkedIn max $8,000. Maximize total customer acquisition value while maintaining brand awareness minimums.",
            "expected_intent": "comprehensive_marketing_optimization",
            "expected_entities": ["channels", "segments", "budget", "roi", "lifetime_value", "conversion"],
            "industry": "marketing",
            "category": "marketing_spend_optimization",
            "difficulty": "advanced",
            "estimated_time": "5-6 minutes"
        },
        "campaign_optimization": {
            "id": "campaign_optimization",
            "title": "Multi-Campaign Performance Optimization",
            "description": "Optimize performance across multiple marketing campaigns with budget constraints",
            "problem_description": "Optimize $25,000 budget across 5 marketing campaigns: Brand Awareness (current spend: $8,000, reach: 500K, engagement: 2.1%), Lead Generation (current spend: $6,000, leads: 1,200, cost per lead: $5.00), Product Launch (current spend: $5,000, conversions: 150, cost per conversion: $33.33), Retargeting (current spend: $4,000, click-through: 8.5%, conversion: 12%), Seasonal Promotion (current spend: $2,000, revenue: $15,000, ROI: 6.5x). Each campaign has minimum spend requirements and maximum capacity limits. Optimize budget allocation to maximize total campaign effectiveness while maintaining brand consistency.",
            "expected_intent": "campaign_optimization",
            "expected_entities": ["campaigns", "budget", "performance_metrics", "constraints"],
            "industry": "marketing",
            "category": "campaign_management",
            "difficulty": "intermediate",
            "estimated_time": "4-5 minutes"
        },
        "customer_acquisition_optimization": {
            "id": "customer_acquisition_optimization",
            "title": "Customer Acquisition Cost Optimization",
            "description": "Optimize customer acquisition across channels to minimize CAC while maximizing LTV",
            "problem_description": "Optimize customer acquisition across 4 channels with $20,000 monthly budget: Paid Search (CAC: $45, LTV: $800, volume capacity: 300 customers), Social Media (CAC: $35, LTV: $650, volume capacity: 400 customers), Content Marketing (CAC: $25, LTV: $1,200, volume capacity: 200 customers), Referral Program (CAC: $15, LTV: $950, volume capacity: 150 customers). Each channel has different customer quality scores and retention rates. Channel minimum spend: $2,000 each. Optimize budget allocation to minimize weighted average CAC while maximizing total customer lifetime value and maintaining acquisition volume targets.",
            "expected_intent": "customer_acquisition_optimization",
            "expected_entities": ["channels", "cac", "ltv", "acquisition", "retention"],
            "industry": "marketing",
            "category": "customer_acquisition",
            "difficulty": "advanced",
            "estimated_time": "4-5 minutes"
        }
    },
    
    "financial": {
        "portfolio_optimization": {
            "id": "portfolio_optimization",
            "title": "Advanced Portfolio Optimization",
            "description": "Optimize multi-asset portfolio with risk constraints and market conditions",
            "problem_description": "Optimize $5M investment portfolio across 8 asset classes with correlation matrix and market constraints: US Large Cap (expected return: 9.2%, volatility: 16.5%, correlation with bonds: -0.3), US Small Cap (expected return: 11.8%, volatility: 22.3%, correlation with bonds: -0.2), International Developed (expected return: 8.5%, volatility: 18.7%, correlation with bonds: -0.1), Emerging Markets (expected return: 12.5%, volatility: 25.8%, correlation with bonds: 0.1), US Bonds (expected return: 4.2%, volatility: 6.8%, correlation with stocks: -0.3), International Bonds (expected return: 3.8%, volatility: 8.2%, correlation with stocks: -0.2), REITs (expected return: 7.5%, volatility: 14.2%, correlation with stocks: 0.6), Commodities (expected return: 6.8%, volatility: 19.5%, correlation with stocks: 0.2). Constraints: Maximum 40% in any single asset class, minimum 20% in bonds, maximum 30% in international assets, maximum 15% in commodities. Risk tolerance: moderate (target volatility: 12-15%). Maximize Sharpe ratio while meeting diversification and risk constraints.",
            "expected_intent": "portfolio_optimization",
            "expected_entities": ["assets", "returns", "volatility", "correlations", "constraints", "risk_tolerance"],
            "industry": "financial",
            "category": "portfolio_management",
            "difficulty": "advanced",
            "estimated_time": "5-6 minutes"
        },
        "credit_risk": {
            "id": "credit_risk",
            "title": "Comprehensive Credit Risk Management",
            "description": "Optimize lending portfolio with risk-based pricing and regulatory constraints",
            "problem_description": "Optimize lending decisions for 500 loan applications across 4 product types: Personal Loans (amounts: $5K-$25K, terms: 12-60 months, interest rates: 8-18%), Auto Loans (amounts: $15K-$50K, terms: 24-84 months, interest rates: 4-12%), Home Equity (amounts: $25K-$200K, terms: 60-180 months, interest rates: 5-9%), Business Loans (amounts: $50K-$500K, terms: 12-120 months, interest rates: 6-15%). Applicant profiles: Credit scores (580-850), Income ($25K-$300K), Debt-to-income (15%-65%), Employment history (1-30 years), Loan-to-value ratios (60%-95%). Risk factors: Default probability (1%-25%), Loss given default (20%-80%), Regulatory capital requirements (8%-12%). Portfolio constraints: Maximum 30% in any single product type, minimum 20% in secured loans, maximum 15% default rate, regulatory capital adequacy ratio > 12%. Maximize risk-adjusted return on capital while maintaining portfolio diversification and regulatory compliance.",
            "expected_intent": "credit_optimization",
            "expected_entities": ["loan_products", "applicants", "risk_factors", "pricing", "regulatory_constraints", "portfolio_diversification"],
            "industry": "financial",
            "category": "credit_risk",
            "difficulty": "advanced",
            "estimated_time": "5-6 minutes"
        },
        "fraud_detection": {
            "id": "fraud_detection",
            "title": "Advanced Fraud Detection & Prevention",
            "description": "Optimize fraud detection system with machine learning models and cost-benefit analysis",
            "problem_description": "Optimize fraud detection system for 10,000 daily transactions across 3 channels: Online Banking (volume: 4,000 transactions, fraud rate: 0.8%, average loss: $2,500), Credit Card (volume: 5,000 transactions, fraud rate: 1.2%, average loss: $1,800), Mobile Payments (volume: 1,000 transactions, fraud rate: 2.1%, average loss: $950). Transaction features: Amount ($1-$50,000), Time of day, Location, Device fingerprint, User behavior patterns. ML model performance: Model A (precision: 95%, recall: 85%, cost: $0.10/transaction), Model B (precision: 92%, recall: 90%, cost: $0.15/transaction), Model C (precision: 98%, recall: 80%, cost: $0.20/transaction). Investigation costs: $25/alert, Customer service impact: $5/false positive. Regulatory requirements: Maximum 0.5% false positive rate, minimum 90% fraud detection rate. Optimize model selection and threshold settings to minimize total fraud losses and operational costs while meeting regulatory requirements.",
            "expected_intent": "fraud_optimization",
            "expected_entities": ["channels", "ml_models", "transaction_features", "costs", "regulatory_requirements", "performance_metrics"],
            "industry": "financial",
            "category": "fraud_detection",
            "difficulty": "advanced",
            "estimated_time": "5-6 minutes"
        }
    },
    
    "logistics": {
        "route_optimization": {
            "id": "route_optimization",
            "title": "Advanced Multi-Modal Route Optimization",
            "description": "Optimize complex delivery routes with multiple vehicles, time windows, and constraints",
            "problem_description": "Optimize delivery routes for 25 customer locations across 3 regions with 8 delivery vehicles of different types. Vehicle types: Small Vans (capacity: 50 units, fuel efficiency: 25 mpg, cost: $0.40/mile, driver cost: $20/hr), Medium Trucks (capacity: 100 units, fuel efficiency: 18 mpg, cost: $0.60/mile, driver cost: $25/hr), Large Trucks (capacity: 200 units, fuel efficiency: 12 mpg, cost: $0.80/mile, driver cost: $30/hr). Customer constraints: Time windows (8AM-5PM), Service times (15-45 minutes), Special requirements (refrigeration, fragile handling), Priority levels (1-3). Distance matrix: 5-120 miles between locations. Regional constraints: Maximum 2 large trucks per region, minimum 1 small van per region. Driver constraints: Maximum 8 hours driving, 30-minute lunch break, overtime costs 1.5x after 8 hours. Minimize total delivery cost while meeting all customer time windows and service requirements.",
            "expected_intent": "route_optimization",
            "expected_entities": ["vehicles", "customers", "time_windows", "constraints", "costs", "regions"],
            "industry": "logistics",
            "category": "route_planning",
            "difficulty": "advanced",
            "estimated_time": "5-6 minutes"
        },
        "fleet_management": {
            "id": "fleet_management",
            "title": "Comprehensive Fleet & Asset Management",
            "description": "Optimize fleet allocation with maintenance, fuel, and operational constraints",
            "problem_description": "Optimize fleet management for 15 vehicles across 6 routes with varying demands and constraints. Fleet composition: 5 Small Vans (capacity: 30 units, daily cost: $80, fuel: $0.35/mile, maintenance: $0.10/mile), 6 Medium Trucks (capacity: 60 units, daily cost: $120, fuel: $0.50/mile, maintenance: $0.15/mile), 4 Large Trucks (capacity: 100 units, daily cost: $180, fuel: $0.70/mile, maintenance: $0.20/mile). Route characteristics: Route A (demand: 45 units, distance: 80 miles, time: 4 hours), Route B (demand: 70 units, distance: 120 miles, time: 6 hours), Route C (demand: 35 units, distance: 60 miles, time: 3 hours), Route D (demand: 85 units, distance: 150 miles, time: 8 hours), Route E (demand: 55 units, distance: 100 miles, time: 5 hours), Route F (demand: 40 units, distance: 70 miles, time: 3.5 hours). Constraints: Vehicle availability (some vehicles in maintenance), Driver availability (12 drivers total), Route compatibility (some routes require specific vehicle types), Maximum daily mileage (300 miles for small, 400 for medium, 500 for large). Minimize total operational cost while meeting all route demands and operational constraints.",
            "expected_intent": "fleet_optimization",
            "expected_entities": ["fleet", "routes", "maintenance", "fuel", "drivers", "constraints"],
            "industry": "logistics",
            "category": "fleet_management",
            "difficulty": "advanced",
            "estimated_time": "5-6 minutes"
        },
        "warehouse_operations": {
            "id": "warehouse_operations",
            "title": "Advanced Warehouse & Distribution Optimization",
            "description": "Optimize warehouse operations with picking, packing, and shipping constraints",
            "problem_description": "Optimize warehouse operations for 200 customer orders across 3 shifts with 8 warehouse workers. Order characteristics: Order sizes (1-15 items), Priority levels (1-3), Shipping methods (Standard, Express, Overnight), Special handling (fragile, hazardous, temperature-controlled). Warehouse layout: 5 zones (A-E) with varying distances, 2,000 SKUs across zones, Picking efficiency varies by zone (Zone A: 25 items/hour, Zone B: 20 items/hour, Zone C: 30 items/hour, Zone D: 18 items/hour, Zone E: 22 items/hour). Worker skills: 3 experienced pickers (25 items/hour), 3 intermediate pickers (20 items/hour), 2 new pickers (15 items/hour). Equipment: 4 forklifts, 6 picking carts, 2 packing stations. Constraints: Shift capacity (8 hours each), Equipment availability, Shipping cut-off times, Quality control requirements. Minimize total order fulfillment time while maintaining quality standards and meeting shipping deadlines.",
            "expected_intent": "warehouse_optimization",
            "expected_entities": ["orders", "workers", "zones", "equipment", "shipping", "constraints"],
            "industry": "logistics",
            "category": "warehouse_operations",
            "difficulty": "advanced",
            "estimated_time": "5-6 minutes"
        }
    },
    
    "energy": {
        "grid_optimization": {
            "id": "grid_optimization",
            "title": "Smart Grid & Energy Distribution Optimization",
            "description": "Optimize energy distribution with renewable integration and demand response",
            "problem_description": "Optimize smart grid energy distribution across 8 zones with 2GW total capacity and varying demand patterns. Generation sources: Coal (capacity: 600 MW, cost: $45/MWh, emissions: 0.9 tCO2/MWh), Natural Gas (capacity: 800 MW, cost: $55/MWh, emissions: 0.4 tCO2/MWh), Solar (capacity: 400 MW, cost: $35/MWh, availability: 25-85% by hour), Wind (capacity: 300 MW, cost: $40/MWh, availability: 20-90% by hour), Hydro (capacity: 200 MW, cost: $25/MWh, availability: 60-100% by hour), Battery Storage (capacity: 100 MW, cost: $80/MWh, efficiency: 85%). Zone demands: Peak (6PM-10PM): 1,800 MW, Off-peak (10PM-6AM): 800 MW, Mid-peak (6AM-6PM): 1,200 MW. Transmission constraints: Line capacities (200-500 MW), Losses (2-8% by distance), Congestion costs ($5-20/MWh). Environmental constraints: Maximum 0.6 tCO2/MWh average, Renewable portfolio standard: 30% minimum. Demand response: 50 MW available at $100/MWh. Minimize total system cost while maintaining grid stability and meeting environmental targets.",
            "expected_intent": "grid_optimization",
            "expected_entities": ["generation", "zones", "renewables", "storage", "demand_response", "emissions"],
            "industry": "energy",
            "category": "grid_management",
            "difficulty": "advanced",
            "estimated_time": "5-6 minutes"
        },
        "renewable_integration": {
            "id": "renewable_integration",
            "title": "Renewable Energy Portfolio Optimization",
            "description": "Optimize renewable energy mix with storage and grid integration",
            "problem_description": "Optimize renewable energy portfolio for 1.5GW system with storage and grid integration. Renewable sources: Solar PV (capacity: 600 MW, capacity factor: 22%, cost: $1,200/kW, degradation: 0.5%/year), Wind Onshore (capacity: 500 MW, capacity factor: 35%, cost: $1,800/kW, degradation: 0.3%/year), Wind Offshore (capacity: 300 MW, capacity factor: 45%, cost: $3,500/kW, degradation: 0.2%/year), Hydro (capacity: 200 MW, capacity factor: 40%, cost: $2,500/kW, degradation: 0.1%/year), Geothermal (capacity: 100 MW, capacity factor: 85%, cost: $4,000/kW, degradation: 0.1%/year). Storage systems: Lithium-ion (capacity: 200 MWh, power: 100 MW, efficiency: 90%, cost: $300/kWh), Pumped hydro (capacity: 500 MWh, power: 150 MW, efficiency: 80%, cost: $150/kWh). Grid integration: Transmission upgrades ($500/kW), Grid services ($20/MWh), Curtailment costs ($30/MWh). Performance targets: 80% renewable penetration, 95% reliability, Maximum 4-hour storage duration. Minimize levelized cost of energy while meeting reliability and environmental targets.",
            "expected_intent": "renewable_optimization",
            "expected_entities": ["renewables", "storage", "capacity_factors", "costs", "grid_integration", "reliability"],
            "industry": "energy",
            "category": "renewable_energy",
            "difficulty": "advanced",
            "estimated_time": "5-6 minutes"
        },
        "maintenance_scheduling": {
            "id": "maintenance_scheduling",
            "title": "Predictive Maintenance & Asset Optimization",
            "description": "Optimize maintenance scheduling with predictive analytics and resource constraints",
            "problem_description": "Optimize maintenance scheduling for 50 energy assets over 12 months with predictive maintenance capabilities. Asset types: Gas Turbines (8 units, criticality: High, maintenance cost: $50K-200K, downtime: 2-7 days, failure probability: 2-8%), Steam Turbines (6 units, criticality: High, maintenance cost: $80K-300K, downtime: 3-10 days, failure probability: 1-6%), Transformers (12 units, criticality: Medium, maintenance cost: $20K-80K, downtime: 1-3 days, failure probability: 3-10%), Solar Inverters (15 units, criticality: Medium, maintenance cost: $5K-15K, downtime: 0.5-2 days, failure probability: 5-15%), Wind Turbines (9 units, criticality: High, maintenance cost: $30K-120K, downtime: 1-5 days, failure probability: 2-7%). Maintenance types: Preventive (scheduled, 70% effectiveness), Predictive (condition-based, 85% effectiveness), Corrective (reactive, 100% effectiveness). Resource constraints: 3 maintenance crews, 2 specialized technicians, Equipment availability, Weather windows (wind/solar), Grid outage windows. Cost factors: Maintenance costs, Lost production ($5K-50K/MW/day), Emergency repair premiums (2x normal cost), Spare parts inventory. Minimize total maintenance cost while maintaining 98% asset availability and preventing catastrophic failures.",
            "expected_intent": "maintenance_optimization",
            "expected_entities": ["assets", "maintenance_types", "predictive_analytics", "resources", "costs", "reliability"],
            "industry": "energy",
            "category": "maintenance",
            "difficulty": "advanced",
            "estimated_time": "5-6 minutes"
        }
    }
}

def get_workflows_for_industry(industry: str) -> List[Dict[str, Any]]:
    """Get all workflows for a specific industry."""
    if industry not in WORKFLOW_TEMPLATES:
        return []
    
    workflows = []
    for workflow_id, workflow_data in WORKFLOW_TEMPLATES[industry].items():
        workflows.append({
            "id": workflow_data["id"],
            "title": workflow_data["title"],
            "description": workflow_data["description"],
            "industry": workflow_data["industry"],
            "category": workflow_data["category"],
            "difficulty": workflow_data["difficulty"],
            "estimated_time": workflow_data["estimated_time"]
        })
    
    return workflows

def get_workflow_details(industry: str, workflow_id: str) -> Dict[str, Any]:
    """Get detailed workflow information for execution."""
    if industry not in WORKFLOW_TEMPLATES:
        return None
    
    if workflow_id not in WORKFLOW_TEMPLATES[industry]:
        return None
    
    return WORKFLOW_TEMPLATES[industry][workflow_id]

def get_all_industries() -> List[str]:
    """Get list of all available industries."""
    return list(WORKFLOW_TEMPLATES.keys())

def get_workflow_summary() -> Dict[str, Any]:
    """Get summary of all workflows by industry."""
    summary = {}
    for industry, workflows in WORKFLOW_TEMPLATES.items():
        summary[industry] = {
            "total_workflows": len(workflows),
            "categories": list(set(w["category"] for w in workflows.values())),
            "difficulty_levels": list(set(w["difficulty"] for w in workflows.values()))
        }
    return summary
