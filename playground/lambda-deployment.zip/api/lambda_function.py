#!/usr/bin/env python3
"""
DcisionAI Manufacturing Playground API
=====================================

Lambda function to handle playground requests and connect to AgentCore runtime.
"""

import json
import logging
import boto3
import base64
import time
from typing import Dict, Any, Optional

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS clients
bedrock_client = boto3.client('bedrock-agentcore', region_name='us-east-1')

# AgentCore runtime ARN
AGENT_RUNTIME_ARN = "arn:aws:bedrock-agentcore:us-east-1:808953421331:runtime/DcisionAI_Manufacturing_Agent_v1_1756943746-0OgdtC2Je6"

def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Lambda handler for playground API requests.
    
    Args:
        event: API Gateway event
        context: Lambda context
        
    Returns:
        API Gateway response
    """
    try:
        # Parse the request
        http_method = event.get('httpMethod', 'POST')
        path = event.get('path', '/')
        
        logger.info(f"Received {http_method} request to {path}")
        
        # Handle CORS preflight
        if http_method == 'OPTIONS':
            return create_cors_response()
        
        # Parse request body
        body = event.get('body', '{}')
        if isinstance(body, str):
            try:
                request_data = json.loads(body)
            except json.JSONDecodeError:
                request_data = {}
        else:
            request_data = body
        
        # Route requests
        if path == '/optimize':
            return handle_optimization_request(request_data)
        elif path == '/health':
            return handle_health_check()
        elif path == '/status':
            return handle_status_check()
        else:
            return create_error_response(404, "Not Found")
            
    except Exception as e:
        logger.error(f"Error processing request: {e}")
        return create_error_response(500, f"Internal Server Error: {str(e)}")

def handle_optimization_request(request_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Handle optimization requests from the playground.
    
    Args:
        request_data: Request data from playground
        
    Returns:
        API Gateway response with optimization results
    """
    try:
        # Extract request parameters
        prompt = request_data.get('prompt', '')
        tenant_context = request_data.get('tenantContext', {
            'tenant_id': 'playground_tenant',
            'sla_tier': 'free',
            'region': 'us-east-1'
        })
        
        if not prompt:
            return create_error_response(400, "Prompt is required")
        
        logger.info(f"Processing optimization request: {prompt[:100]}...")
        logger.info(f"Tenant context: {tenant_context}")
        
        # Create MCP protocol request
        mcp_request = {
            "jsonrpc": "2.0",
            "id": f"playground-{int(time.time())}",
            "method": "invoke",
            "params": {
                "prompt": prompt,
                "tenantContext": tenant_context,
                "session_id": f"playground-session-{int(time.time())}"
            }
        }
        
        # Convert to base64 for AWS CLI
        request_json = json.dumps(mcp_request)
        request_base64 = base64.b64encode(request_json.encode()).decode()
        
        # Call AgentCore runtime using subprocess (like our working MCP client)
        try:
            import subprocess
            import tempfile
            
            # Create temporary file with the request
            with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
                json.dump(mcp_request, f)
                temp_file = f.name
            
            # Use AWS CLI to invoke AgentCore (this works reliably)
            cmd = [
                'aws', 'bedrock-agentcore', 'invoke-agent-runtime',
                '--agent-runtime-arn', AGENT_RUNTIME_ARN,
                '--qualifier', 'DEFAULT',
                '--payload', f'file://{temp_file}',
                '--content-type', 'application/json',
                '--accept', 'application/json',
                '--region', 'us-east-1'
            ]
            
            logger.info(f"Executing command: {' '.join(cmd)}")
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
            
            # Clean up temp file
            import os
            os.unlink(temp_file)
            
            if result.returncode != 0:
                logger.error(f"Command failed: {result.stderr}")
                raise Exception(f"AWS CLI command failed: {result.stderr}")
            
            # Parse the response
            response_data = json.loads(result.stdout)
            logger.info(f"AgentCore response: {response_data}")
            
            # Extract completion from response
            if 'completion' in response_data:
                response = {'completion': response_data['completion']}
            else:
                response = response_data
            
            # Parse response
            if 'completion' in response:
                response_data = json.loads(response['completion'])
                
                # Check if it's a JSON-RPC response
                if 'result' in response_data:
                    result_data = response_data['result']
                    
                    return create_success_response({
                        "success": True,
                        "workflow_results": result_data.get('workflow_results', {}),
                        "message": result_data.get('message', 'Optimization completed'),
                        "tools_used": result_data.get('tools_used', []),
                        "tenant_context": result_data.get('tenant_context', {}),
                        "inference_profiles_used": result_data.get('inference_profiles_used', []),
                        "mcp_protocol": result_data.get('mcp_protocol', {}),
                        "execution_time": response.get('executionTime', 0),
                        "session_id": response.get('runtimeSessionId', 'unknown')
                    })
                else:
                    # Handle error response
                    error_data = response_data.get('error', {})
                    return create_error_response(400, f"Optimization failed: {error_data.get('message', 'Unknown error')}")
            else:
                return create_error_response(500, "Invalid response from AgentCore runtime")
                
        except Exception as e:
            logger.error(f"AgentCore invocation failed: {e}")
            
            # Return error instead of simulated results - we want real tool execution
            return create_error_response(500, f"AgentCore runtime error: {str(e)}")
            
    except Exception as e:
        logger.error(f"Error handling optimization request: {e}")
        return create_error_response(500, f"Error processing request: {str(e)}")

def generate_simulated_results(prompt: str, tenant_context: Dict[str, Any]) -> Dict[str, Any]:
    """
    Generate simulated optimization results for demo purposes.
    
    Args:
        prompt: User prompt
        tenant_context: Tenant context
        
    Returns:
        Simulated optimization results
    """
    import random
    
    # Analyze prompt to determine intent
    prompt_lower = prompt.lower()
    
    if 'scheduling' in prompt_lower or 'schedule' in prompt_lower:
        primary_intent = 'production_scheduling'
        objectives = ['minimize_costs', 'meet_demand', 'maximize_efficiency']
        model_type = 'linear_programming'
        solver = 'ortools'
    elif 'quality' in prompt_lower or 'defect' in prompt_lower:
        primary_intent = 'quality_optimization'
        objectives = ['minimize_defects', 'maximize_quality', 'optimize_process_parameters']
        model_type = 'nonlinear_programming'
        solver = 'highs'
    elif 'supply' in prompt_lower or 'chain' in prompt_lower:
        primary_intent = 'supply_chain_optimization'
        objectives = ['minimize_costs', 'maintain_service_levels', 'optimize_inventory']
        model_type = 'mixed_integer_programming'
        solver = 'gurobi'
    else:
        primary_intent = 'general_optimization'
        objectives = ['minimize_costs', 'maximize_efficiency', 'meet_constraints']
        model_type = 'linear_programming'
        solver = 'ortools'
    
    return {
        "success": True,
        "workflow_results": {
            "intent_classification": {
                "primary_intent": primary_intent,
                "confidence": 0.85 + random.random() * 0.1,
                "objectives": objectives,
                "reasoning": f"Classified as {primary_intent} based on keywords in query",
                "inference_profile_used": f"dcisionai-{tenant_context.get('sla_tier', 'free')}-tier-production",
                "tenant_tier": tenant_context.get('sla_tier', 'free')
            },
            "data_analysis": {
                "data_entities": ['production_data', 'demand_forecasts', 'resource_constraints', 'quality_metrics'],
                "missing_data": [],
                "sample_data": {
                    "production_capacity": 1000,
                    "demand_forecast": 850,
                    "defect_rate": 0.023,
                    "cost_per_unit": 45.50
                },
                "analysis": f"Based on {primary_intent} intent analysis, identified 4 critical data requirements.",
                "priority": "high",
                "inference_profile_used": f"dcisionai-{tenant_context.get('sla_tier', 'free')}-tier-production",
                "tenant_tier": tenant_context.get('sla_tier', 'free'),
                "data_complexity": 4,
                "estimated_data_volume": 5000
            },
            "model_building": {
                "model_type": model_type,
                "decision_variables": 12 + random.randint(0, 8),
                "constraints": 15 + random.randint(0, 10),
                "complexity": "medium",
                "inference_profile_used": f"dcisionai-{tenant_context.get('sla_tier', 'free')}-tier-production",
                "tenant_tier": tenant_context.get('sla_tier', 'free'),
                "model_insights": f"Necessary for {primary_intent} with complex business constraints",
                "estimated_solve_time": "1.2-3.6 seconds",
                "scalability": "Medium"
            },
            "optimization_solving": {
                "status": "optimal",
                "objective_value": 45000 + random.random() * 10000,
                "solve_time": 1.5 + random.random() * 2,
                "recommended_solver": solver,
                "available_solvers": [solver, 'ortools', 'highs'],
                "solution_quality": "high",
                "inference_profile_used": f"dcisionai-{tenant_context.get('sla_tier', 'free')}-tier-production",
                "tenant_tier": tenant_context.get('sla_tier', 'free'),
                "solver_insights": f"{solver} solver provides optimal solution for this problem type",
                "convergence_iterations": 150 + random.randint(0, 100),
                "memory_usage_mb": 80 + random.random() * 40,
                "optimization_metrics": {
                    "gap": 0.01 + random.random() * 0.05,
                    "feasibility_tolerance": 1e-06,
                    "optimality_tolerance": 1e-06
                }
            }
        },
        "message": "Manufacturing optimization workflow completed successfully",
        "tools_used": ['manufacturing_intent_classifier', 'manufacturing_data_analyzer', 'manufacturing_model_builder', 'manufacturing_optimization_solver'],
        "tenant_context": tenant_context,
        "inference_profiles_used": [f"dcisionai-{tenant_context.get('sla_tier', 'free')}-tier-production"] * 4,
        "mcp_protocol": {
            "version": "2024-11-05",
            "content_type": "application/json",
            "session_id": f"playground-session-{int(time.time())}"
        },
        "execution_time": 1.5 + random.random() * 2,
        "session_id": f"playground-session-{int(time.time())}"
    }

def handle_health_check() -> Dict[str, Any]:
    """Handle health check requests."""
    return create_success_response({
        "status": "healthy",
        "timestamp": time.time(),
        "service": "DcisionAI Manufacturing Playground API",
        "version": "1.0.0",
        "agentcore_connected": True
    })

def handle_status_check() -> Dict[str, Any]:
    """Handle status check requests."""
    try:
        # Check AgentCore runtime status
        response = bedrock_client.get_agent_runtime(
            agentRuntimeId=AGENT_RUNTIME_ARN.split('/')[-1]
        )
        
        return create_success_response({
            "status": "operational",
            "agentcore_runtime": {
                "status": response.get('status', 'unknown'),
                "arn": response.get('agentRuntimeArn', 'unknown'),
                "version": response.get('agentRuntimeVersion', 'unknown')
            },
            "timestamp": time.time()
        })
    except Exception as e:
        logger.error(f"Status check failed: {e}")
        return create_success_response({
            "status": "degraded",
            "error": str(e),
            "timestamp": time.time()
        })

def create_success_response(data: Dict[str, Any]) -> Dict[str, Any]:
    """Create a successful API Gateway response."""
    return {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
            'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
        },
        'body': json.dumps(data, indent=2)
    }

def create_error_response(status_code: int, message: str) -> Dict[str, Any]:
    """Create an error API Gateway response."""
    return {
        'statusCode': status_code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
            'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
        },
        'body': json.dumps({
            'error': True,
            'message': message,
            'timestamp': time.time()
        }, indent=2)
    }

def create_cors_response() -> Dict[str, Any]:
    """Create a CORS preflight response."""
    return {
        'statusCode': 200,
        'headers': {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
            'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
        },
        'body': ''
    }
