#!/usr/bin/env python3
"""
Simple test Lambda function
"""

import json

def lambda_handler(event, context):
    return {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps({
            'message': 'Test successful',
            'event': event
        })
    }
